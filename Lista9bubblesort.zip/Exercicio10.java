public class Main {
    public static void main(String[] args) {
        System.out.println("O Bubble Sort não é utilizado em aplicações de grande escala porque:");
        System.out.println("baixa eficiência em grandes volumes de dados, complexidade O(n²), alto número de comparações, muitas trocas desnecessárias, quick sort e merge sort acabaram substituindo ele.");
    }
}